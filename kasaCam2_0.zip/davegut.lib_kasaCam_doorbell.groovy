library (
	name: "lib_kasaCam_doorbell",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Methods explicit to the Kasa Doorbell varient.",
	category: "utilities",
	documentationLink: ""
)

capability "AudioVolume"
command "quickResponse", [
	[name: "response",
	 constraints: ["Can't Answer", "Leave Item", "One Minute",
				   "Not Interested", "Calling Police"], type: "ENUM"]]
command "doNotDisturb", [[
	name: "Do Not Disturb on/off",
	constraints: ["true", "false"],
	type: "ENUM"]]
attribute "doNotDisturb", "bool"

def mute() { setVolume(0) }
def unmute() { setVolume(state.lastVolume) }
def volumeUp() {
	def curVolume = device.currentValue("volume").toInteger()
	if (curVolume != 100) {
		def newVolume = curVolume + 10
		if (newVolume > 100) { newVolume = 100 }
		setVolume(newVolume)
	}
}
def volumeDown() {
	def curVolume = device.currentValue("volume").toInteger()
	if (curVolume != 0) {
		def newVolume = curVolume - 10
		if (newVolume <= 0) { newVolume = 0 }
		setVolume(newVolume)
	}
}
def setVolume(volume) {
	if (volume < 0 || volume > 100) {
		Map logData = [method: "setVolume", status: "ERROR", data: "Volume ${volume} is out of range"]
		logWarn logData
		return
	}
	Map cmdData = [
		"smartlife.cam.ipcamera.audio":[
			set_mic_config:[volume: volume],
			get_mic_config:[]]]
	asyncPost(cmdData, "setVolume")
}

def doNotDisturb(enable) {
	def enab = true
	if (enable == "false") { enab = false }
	Map cmdData = [
		"smartlife.cam.ipcamera.dndSchedule":[
			set_dnd_enable:[enable: enab],
			get_dnd_enable:[]]]
	asyncPost(cmdData, "setDoNotDisturb")
}

def quickResponse(response) {
	def respNo = 1
	switch (response) {
		case "Can't Answer": respNo = 1; break
		case "Leave Item": respNo = 2; break
		case "One Minute": respNo = 3; break
		case "Not Interested": respNo = 4; break
		case "Calling Police": respNo = 5; break
		default: respNo = 1
	}
	Map cmdData = [
		"smartlife.cam.ipcamera.audio":[
			set_quickres_state:[file_id: respNo]
	]]
	asyncPost(cmdData, "quickResponse")
}

