library (
	name: "lib_kasaCam_transport",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Kasa Camera transport methods",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.net.URLEncoder

def testCreds() {
	def newCredType = credType
	Map cmdData = [system: [get_sysinfo:[]]]
	def respData = syncPost(cmdData, "testCreds")
	if (!respData["system"]) {
		if (newCredType == "single_pass") {
			newCredType = "dual_pass"
		} else {
			newCredType = "single_pass"
		}
		device.updateSetting("credType", [type:"enum", value: newCredType])
	}
	return newCredType
}

def getCreds() {
	def creds = parent.credentials
	if (credType == "dual_pass") { 
		creds = parent.altCredentials }
	return creds
}
def asyncPost(cmdBody, sourceMethod) {
	Map cmdData = [body: cmdBody, source: sourceMethod]
	state.lastCmd = cmdData
	Map logData = [method: "asyncSend", cmdBody: cmdBody, 
				   credType: credType]
	def reqParams = [
		uri: "https://${getDataValue("deviceIp")}:10443/data/LINKIE.json",
		body: "content=${stringifyCmd(cmdBody)}",
		contentType: "text/plain",
		ignoreSSLIssues: true,
		headers: [
			"Authorization": "Basic ${getCreds()}",
		],
		timeout: 5,
	]
	try {
		asynchttpPost("parseAsyncPost", reqParams, [cmd: cmdBody, source: sourceMethod])
		logData << [status: "OK"]
	} catch (err) {
		logData << [status: "FAILED", error: err]
		logWarn(logData)
		handleCommsError([error: "parseAsyncPost"])
	}
	logDebug(logData)
}
def parseAsyncPost(resp, data) {
	Map respData = [:]
	if (resp.status == 200) {
		byte[] respByte = resp.data.decodeBase64()
		String encResp = hubitat.helper.HexUtils.byteArrayToHexString(respByte)
		respData = new JsonSlurper().parseText(inputXOR(encResp))
		if (!respData.err_code) {
			distRespData(respData, data.source)
			setCommsError(false)
		} else {
			Map logData = [method: "parseAsyncPost", status: "errorInReturn",
						   respData: respData]
		handleCommsError([error: "parseAsyncPost"])
		handleCommsError(data)
		}
	} else {
		Map logData = [method: "parseAsyncPost", status: resp.status, data: data, 
					   resp: resp.properties]
		logWarn(logData)
		handleCommsError([error: "parseAsyncPost"])
	}
}

def stringifyCmd(cmdData) {
	def cmdJson = JsonOutput.toJson(cmdData).toString()
	def encCmd = outputXOR(cmdJson)
 	byte[] bufByte = hubitat.helper.HexUtils.hexStringToByteArray(encCmd)
	def b64Cmd = new String(bufByte.encodeBase64().toString())
	return URLEncoder.encode(b64Cmd)
}

def syncPost(cmdBody, sourceMethod) {
	Map logData = [method: "syncSend", cmdBody: cmdBody, sourceMethod: sourceMethod, 
				   credType: credType]
	def reqParams = [
		uri: "https://${getDataValue("deviceIp")}:10443/data/LINKIE.json",
		body: "content=${stringifyCmd(cmdBody)}",
		contentType: "application/octet-stream",
		ignoreSSLIssues: true,
		headers: [
			"Authorization": "Basic ${getCreds()}",
		],
		timeout: 4,
	]
	Map respData = [:]
	try {
		httpPost(reqParams) { resp ->
			logData << [status: resp.status]
			if (resp.status == 200) {
				byte[] data = parseInputStream(resp.data)
				String dataB64 = new String(data)
				byte[] respByte = dataB64.decodeBase64()
				String encResp = hubitat.helper.HexUtils.byteArrayToHexString(respByte)
				respData = new JsonSlurper().parseText(inputXOR(encResp))
				setCommsError(false)
			} else {
				logData << [errorType: "responseError", data: resp.data]
				respData << [status: resp.status, errorType: "httpResponseError"]
				logWarn(logData)
				handleCommsError([error: "syncPost"])
			}
		}
	} catch (err) {
		logData << [status: "httpError", error: err]
		respData << [status: "httpError", errorType: "httpResponseError"]
		logWarn(logData)
		handleCommsError([error: "syncPost"])
	}
	logDebug(logData)
	return respData
}
def parseInputStream(data) {
	def dataSize = data.available()
	byte[] dataArr = new byte[dataSize]
	data.read(dataArr, 0, dataSize)
	return dataArr
}

//	===== Error Handling =====
def handleCommsError(data) {
	def count = state.errorCount + 1
	state.errorCount = count
	Map logData = [method: "handleCommsError", data: data, count: count]
	logData << [count: count, data: data]
	switch (count) {
		case 1:
			//	Unschedule poll then retry the command (in case error is transient)
			unschedule("poll")
			runIn(1, delayedPassThrough, [data: data])
			logData << [action: "retryCommand"]
			logInfo(logData)
			break
		case 2:
			logData << [checkConnect: parent.checkConnect()]
			logData << [action: "retryCommand"]
			runIn(1, delayedPassThrough, [data: data])
			logInfo(logData)
			break
		case 3:
			logData << [commsError: setCommsError(true)]
			logWarn(logData)
			break
		default:
			logData << [status: "retriesDisabled"]
			logDebug(logData)
			break
	}
}

def delayedPassThrough(data) {
	asyncPost(data.cmd, data.source)
}

def setCommsError(status) {
	if (status == false && state.errorCount == 0) {
		//	no existing and no current error.  Do nothing
	} else if (status == false) {
		//	current error.  Reset attribute, reschedule poll interval to user-selected.
		updateAttr("commsError", false)
		state.errorCount = 0
		setPollInterval()
		return [method: "setCommsError", status: "cleared"]
	} else {
		//	status is true.  set comms error, slow down polling.
		updateAttr("commsError", true)
		setPollInterval("error")
		return [method: "setCommsError", status: "set"]
	}
}
//	===== XOR Encode/Decode =====
private outputXOR(command) {
	def str = ""
	def encrCmd = ""
 	def key = 0xAB
	for (int i = 0; i < command.length(); i++) {
		str = (command.charAt(i) as byte) ^ key
		key = str
		encrCmd += Integer.toHexString(str)
	}
   	return encrCmd
}
private inputXOR(encrResponse) {
	String[] strBytes = encrResponse.split("(?<=\\G.{2})")
	def cmdResponse = ""
	def key = 0xAB
	def nextKey
	byte[] XORtemp
	for(int i = 0; i < strBytes.length; i++) {
		nextKey = (byte)Integer.parseInt(strBytes[i], 16)
		XORtemp = nextKey ^ key
		key = nextKey
		cmdResponse += new String(XORtemp)
	}
	return cmdResponse
}
