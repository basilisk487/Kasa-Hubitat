/*	Kasa Device Driver Series
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Link to list of changes =====
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/Changes.pdf
===== Link to Documentation =====
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/Documentation.pdf

Notes on Camera: Older models do not support the 24/7 control function.  Need testing
on newer models to determine if these support that reporting.

===================================================================================================*/
metadata {
	definition (name: "kasaDoorbell",
				namespace: "davegut",
				author: "Dave Gutheinz",
				importUrl: ""
			   ) {
		capability "Configuration"
		capability "VideoCamera"
		command "on", [[name: "Privacy Mode On"]]
		command "off", [[name: "Privacy Mode Off"]]
		command "flip", [[name: "NOT IMPLEMENTED"]]
		capability "Motion Sensor"
		command "setPollInterval", [[
			name: "Poll Interval in seconds",
			constraints: ["off", "5", "10", "15", "30"],
			type: "ENUM"]]
		command "nightVision", [[
			name: "Night Vision Mode",
			constraints: ["day", "night", "auto"],
			type: "ENUM"]]
		attribute "nightVision", "string"
		capability "Refresh"
		attribute "sdCard", "string"
		attribute "commsError", "bool"
	}
	preferences {
		input ("motionDetect", , "enum", title: "Motion Detect",
			   options: ["on", "off"], defaultValue: "on")
		input ("motionSens", "enum", title: "Motion Detect Sensitivity",
			   options: ["low", "medium", "high"], defaultValue: "low")
		input ("triggerTime", "number", title: "Record if motion lasts (msec)",
			   defaultValue: 1000)
		input ("personDetect", "enum", title: "Person Detect",
			   options: ["on", "off"], defaultValue: "on")
		input ("soundDetect", "enum", title: "Sound Detect",
			   options: ["on", "off"], defaultValue: "on")
		input ("soundDetSense", "enum", title: "Sound Detection Senvitivity",
			   options: ["low", "medium", "high"], defaultValue: "low")
		input ("cvrOnOff", "enum", title: "Continuous Video Record",
			   options: ["on", "off"], defaultValue: "on")
		input ("clipAudio", "enum", title: "Clip Audio Recording", 
			   options: ["on", "off"], defaultValue: "on")
		input ("dbLedOnOff", "enum", title: "Doorbell Button LED",
			   options: ["on", "off"], defaultValue: "on")
		input ("ledOnOff", "enum", title: "LED",
			   options: ["on", "off"], defaultValue: "on")
		input ("infoLog", "bool", title: "Enable information logging",defaultValue: true)
		input ("logEnable", "bool", title: "Enable debug logging", defaultValue: true)
		input("credType", "enum", title: "Credential Type (CAUTION)",
			  options: ["single_pass", "dual_pass"], defaultValue: "single_pass")
	}
}

def installed() {
	def waitFor = configure(true)
	device.updateSetting("logEnable", [type:"bool", value: false])
}

def updated() {
	unschedule()
	def updStatus = [method: "updated"]
	if (logEnable) { runIn(1800, debugLogOff) }
	if (checkCreds) {
		updStatus << [credType: testCreds()]
	}
	updStatus << [textEnable: infoLog, logEnable: logEnable]
	updStatus << [pollInterval: setPollInterval(state.pollInterval)]
	updStatus << [setPreferences: setPreferences()]
	updateAttr("commsError", false)
	state.errorCount = 0
	state.remove("lastCmd")
	pauseExecution(5000)
	runEvery1Hour(refresh)
	logInfo(updStatus)
}

def setPreferences() {
	Map logData = [:]
	Map cmdData = [
		"smartlife.cam.ipcamera.motionDetect":[
			set_is_enable:[value: motionDetect],
			set_sensitivity:[value: motionSens],
			set_min_trigger_time:[
				day_mode_value: triggerTime,
				night_mode_value: triggerTime]],
		"smartlife.cam.ipcamera.led":[
			set_status:[value: ledOnOff],
			set_buttonled_status:[value: dbLedOnOff]],
		"smartlife.cam.ipcamera.soundDetect":[
			set_is_enable:[value: soundDetect],
			set_sensitivity:[value: soundDetSense]],
		"smartlife.cam.ipcamera.intelligence":[
			set_pd_enable:[value: personDetect]],
		"smartlife.cam.ipcamera.delivery":[
			set_clip_audio_is_enable:[value:clipAudio]]
	]
	if (device.currentValue("sdCard") == "ok") {
		cmdData << ["smartlife.cam.ipcamera.vod":[
			set_is_enable:[value: cvrOnOff]]]
	}
	def respData = syncPost(cmdData, "setPreferences")
	if (respData == "ERROR") {
		logData << [status: "FAILED", respData: respData]
	} else {
		logData << [status: "OK"]
	}
	def waitFor = refresh()
	return logData
}

def getPreferences() {
	Map prefs = [motionDetect: motionDetect, motionSens: motionSens,
				 triggerTime: triggerTime, personDetect: personDetect,
				 soundDetect: soundDetect, soundDetSense: soundDetSense,
				 cvrOnOff: cvrOnOff, clipAudio: clipAudio,
				 dbLedOnOff: dbLedOnOff, ledOnOff: ledOnOff]
	return prefs
}

//	===== Device Command Methods =====
def flip() {
	logWarn("FLIP COMMAND NOT IMPLEMENTED!")
}

//	===== refesh methods =====
def refresh() {
	def endTime = (now()/1000).toInteger()
	def startTime = endTime - 3600
	Map cmdData = [
		"smartlife.cam.ipcamera.motionDetect":[get_is_enable:[]],
		"smartlife.cam.ipcamera.led":[get_status:[]],
		"smartlife.cam.ipcamera.sdCard":[get_sd_card_state:[]],
		"smartlife.cam.ipcamera.soundDetect":[get_is_enable:[]],
		"smartlife.cam.ipcamera.intelligence":[get_pd_enable:[]],
		"smartlife.cam.ipcamera.delivery":[get_clip_audio_is_enable:[]],
		"smartlife.cam.ipcamera.audio":[get_mic_config:[]],
		"smartlife.cam.ipcamera.dndSchedule":[get_dnd_enable:[]],
		"smartlife.cam.ipcamera.dayNight":[get_mode:[]],
		"smartlife.cam.ipcamera.vod":[get_is_enable:[]]]
	asyncPost(cmdData, "refresh(1)")
	pauseExecution(3000)
	cmdData = [
		"smartlife.cam.ipcamera.motionDetect":[get_sensitivity:[]],
		"smartlife.cam.ipcamera.soundDetect":[get_sensitivity:[]],
		"smartlife.cam.ipcamera.vod":[get_detect_zone_list: [start_time: startTime, end_time: endTime]],
		"smartlife.cam.ipcamera.led":[get_buttonled_status:[]]]
	asyncPost(cmdData, "refresh(2)")
	pauseExecution(2000)
	cmdData = [
		"smartlife.cam.ipcamera.switch":[get_is_enable:[]],
		"smartlife.cam.ipcamera.motionDetect":[get_min_trigger_time:[]]]
	asyncPost(cmdData, "refresh(3)")
	pauseExecution(3000)
	return "commandsSent"
}

//	===== Library Includes =====
#include davegut.lib_kasaCam_transport
#include davegut.lib_kasaCam_common
#include davegut.Logging
#include davegut.lib_kasaCam_doorbell
