library (
	name: "lib_kasaCam_common",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Methods common to Kasa Camera variants",
	category: "utilities",
	documentationLink: ""
)

//	Installation / Configuration
def configure(inst=false) {
	logInfo([method: "configure", startDeviceIp: getDataValue("deviceIp")])
	Map logData = [method: "configure", inst: inst]
	updateAttr("commsError", false)
	state.pollInterval = "30"
	state.errorCount = 0
	if (!inst) {
		def waitFor = parent.findDevices(true)
		logData << [updatedDeviceIp: getDataValue("deviceIp")]
		logData << [credType: testCreds()]
	}
	logData << [refresh: refresh()]
	logData << [attributes: listAttributes()]
	logData << [preferences: getPreferences()]
	logInfo(logData)
	return
}

//	===== Command =====
def on() { setCamera("on") }
def off() { setCamera("off") }
def setCamera(onOff) {
	Map cmdData = [
		"smartlife.cam.ipcamera.switch":[
			set_is_enable:[value: onOff],
			get_is_enable:[:]]]
	asyncPost(cmdData, "setCamera")
}

def nightVision(mode) {
	Map cmdData = [
		"smartlife.cam.ipcamera.dayNight":[
			set_mode:[value: mode],
			get_mode:[]]]
	asyncPost(cmdData, "setNightVision")
}

def setPollInterval(interval) {
	unschedule("poll")
	//	update state.pollInterval unless called from a commsError.
	//	Then do not so poll is recovered on error recovery.
	if (interval == "error") {
		runEvery5Minutes("poll")
		interval = "5 minutes"
	} else {
		if (interval == null) { 
			interval = "30"
		}
		state.pollInterval = interval
		if (interval != "off") {
			schedule("3/${interval} * * * * ?", "poll")
		}
	}
	logDebug([method: "setPollInterval", pollInterval: interval])
	return interval
}
def poll() {
	Map cmdData = [system: [get_sysinfo:[]]]
	asyncPost(cmdData, "motionParse")
}

def rebootDev() {
	Map cmdData = [
		"smartlife.cam.ipcamera.system":[
			set_reboot:[]]]
	asyncPost(cmdData, "rebootDev")
}

//	===== Distribute Async Response and Parse Data =====
def distRespData(respData, source) {
	Map logData = [method: "distRespData", source: source]
	def error = false
	respData.each {
		if (respData == "ERROR") {
			error = true
			logData << [respData: respData]
		} else if (it.value.err_code && it.value.err_code !=0) {
			error = true
			logData << ["${it.key}": it.value]
		} else {
			switch(it.key) {
				case "system": motionParse(it, source); break
				case "smartlife.cam.ipcamera.dayNight": parseDayNight(it, source); break
				case "smartlife.cam.ipcamera.dndSchedule": parseDndSchedule(it, source); break
				case "smartlife.cam.ipcamera.switch": parseSwitch(it, source); break
				case "smartlife.cam.ipcamera.audio": parseAudio(it, source); break
				case "smartlife.cam.ipcamera.ptz": parsePtz(it, source); break
				case "smartlife.cam.ipcamera.vod": parseVod(it, source); break
				case "smartlife.cam.ipcamera.delivery": parseDelivery(it, source); break
				case "smartlife.cam.ipcamera.intelligence": parseIntel(it, source); break
				case "smartlife.cam.ipcamera.soundDetect": parseSoundDetect(it, source); break
				case "smartlife.cam.ipcamera.led": parseLed(it, source); break
				case "smartlife.cam.ipcamera.sdCard": parseSdCard(it, source); break
				case "smartlife.cam.ipcamera.motionDetect": parseMotionDetect(it, source); break
				default: 
					logData << ["${it.key}": "unhandled", data: it]
					error = true
			}
		}
	}
	if (error == true) {
		logWarn(logData)
	} else {
		logDebug(logData)
	}
}

def motionParse(respData, source) {
	def resp = respData.value.get_sysinfo.system
	def lastActTime = resp.last_activity_timestamp
	def sysTime = resp.system_time
	def deltaTime = sysTime - lastActTime
	if (lastActTime > state.lastActiveTime) {
		updateAttr("motion", "active")
		state.lastActiveTime = lastActTime
	} else if (device.currentValue("motion") == "active" &&
			   15 < deltaTime) {
		updateAttr("motion", "inactive")
	}
}

def parseSdCard(data, source) {
	Map logData = [method: "parseSdCard", source: source]
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			def setting = "ERROR"
			switch(key) {
				case "get_sd_card_state":
					setting = it.value.state
					updateAttr("sdCard", setting)
					valueLog << [sdCard: setting, status: "OK"]
					break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]
	}
	logDebug(logData)
}

def parseDayNight(data, source) {
	Map logData = [method: "parseDayNight", source: source]
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			def setting = "ERROR"
			switch(key) {
				case "set_mode": break
				case "get_mode":
					setting = it.value.value
					updateAttr("nightVision", setting)
					valueLog << [nightVision: setting, status: "OK"]
					break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]
	}
	logDebug(logData)
}

def parseDndSchedule(data, source) {
	Map logData = [method: "parseDndSchedule", source: source]
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			def setting = "ERROR"
			switch(key) {
				case "set_dnd_enable": break
				case "get_dnd_enable":
					setting = it.value.enable
					updateAttr("doNotDisturb", setting)
					valueLog << [doNotDisturb: setting, status: "OK"]
					break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]
	}
	logDebug(logData)
}

def parseAudio(data, source) {
	Map logData = [method: "parseAudio", source: source]
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			def setting = "ERROR"
			switch(key) {
				case "set_mic_config": break
				case "get_mic_config":
					setting = it.value.volume
					def mute = "muted"
					if (setting > 0) {
						state.lastVolume = setting
						mute = "unmuted"
					}
					updateAttr("mute", mute)
					updateAttr("volume", setting)
					valueLog << [volume: setting, mute: mute, status: "OK"]
				case "set_quickres_state": 
					valueLog << [status: "OK"]
					break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]
	}
	logDebug(logData)
}

def parseSwitch(data, source) {
	Map logData = [method: "parseSwitch", source: source]
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			def setting = "ERROR"
			switch(key) {
				case "set_is_enable": break;
				case "get_is_enable":
					setting = it.value.value
					updateAttr("camera", setting)
					valueLog << [camera: setting, status: "OK"]
					runIn(5, loadCameraSettings)
					break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]
	}
	logDebug(logData)
}

def loadCameraSettings() {
	Map settings = [md: motionDetect,
					sd: soundDetect,
					pd: personDetect,
					cvr: cvrOnOff]
		updateAttr("settings", settings)
}

def parseMotionDetect(data, source) {
	Map logData = [method: "parseMotionDetect", source: source]
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			logData << ["${key}": [error: it.value.err_code]]
			def setting = "ERROR"
			switch(key) {
				case "set_sensitivity": break;
				case "get_sensitivity":
					setting = it.value.value
					device.updateSetting("motionSens", [type:"enum", value: setting])
					valueLog << [motionSens: setting, status: "OK"]
					break
				case "set_is_enable": break;
				case "get_is_enable":
					setting = it.value.value
					device.updateSetting("motionDetect", [type:"enum", value: setting])
					valueLog << [motionDetect: setting, status: "OK"]
					break
				case "set_min_trigger_time": break;
				case "get_min_trigger_time":
					setting = it.value.day_mode_value
					device.updateSetting("triggerTime", [type:"enum", value: setting])
					valueLog << [triggerTime: setting, status: "OK"]
					break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]

	}
	logDebug(logData)
}

def parseLed(data, source) {
	Map logData = [method: "parseLed", source: source]
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			logData << ["${key}": [error: it.value.err_code]]
			def setting = "ERROR"
			switch(key) {
				case "set_buttonled_status": break;
				case "get_buttonled_status":
					setting = it.value.value
					device.updateSetting("dbLedOnOff", [type:"enum", value: setting])
					valueLog << [dbLedOnOff: setting, status: "OK"]
					break
				case "set_status": break;
				case "get_status":
					setting = it.value.value
					device.updateSetting("ledOnOff", [type:"enum", value: setting])
					valueLog << [ledOnOff: setting, status: "OK"]
					break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]

	}
	logDebug(logData)
}

def parseSoundDetect(data, source) {
	Map logData = [method: "parseSoundDetect", source: source]
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			logData << ["${key}": [error: it.value.err_code]]
			def setting = "ERROR"
			switch(key) {
				case "set_is_enable": break;
				case "get_is_enable":
					setting = it.value.value
					device.updateSetting("soundDetect", [type:"enum", value: setting])
					valueLog << [soundDetect: setting, status: "OK"]
					break
				case "set_sensitivity": break;
				case "get_sensitivity":
					setting = it.value.value
					device.updateSetting("soundDetSense", [type:"enum", value: setting])
					valueLog << [soundDetSense: setting, status: "OK"]
					break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]

	}
	logDebug(logData)
}

def parseIntel(data, source) {
	Map logData = [method: "parseIntel", source: source]
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			logData << ["${key}": [error: it.value.err_code]]
			def setting = "ERROR"
			switch(key) {
				case "set_pd_enable": break;
				case "get_pd_enable":
					setting = it.value.value
					device.updateSetting("personDetect", [type:"enum", value: setting])
					valueLog << [personDetect: setting, status: "OK"]
					break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]

	}
	logDebug(logData)
}

def parseDelivery(data, source) {
	Map logData = [method: "parseDelivery", source: source]
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			def setting = "ERROR"
			switch(key) {
				case "set_clip_audio_is_enable": break;
				case "get_clip_audio_is_enable":
					setting = it.value.value
					device.updateSetting("clipAudio", [type:"enum", value: setting])
					valueLog << [clipAudio: setting, status: "OK"]
					break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]
	}
	logDebug(logData)
}

def parseVod(data, source) {
	Map logData = [method: "parseVod", source: source]
	def error = false
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			def setting = "ERROR"
			switch(key) {
				case "set_is_enable": break;
				case "get_is_enable":
					setting = it.value.value
					device.updateSetting("cvrOnOff", [type:"enum", value: setting])
					logData << [cvrOnOff: setting, status: "OK"]
					break
				case "get_detect_zone_list":
					setting = it.value.list
					state.recentEvents = setting
					logData << [recentEvents: setting, status: "OK"]	
					break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]
	}
	logDebug(logData)
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}
