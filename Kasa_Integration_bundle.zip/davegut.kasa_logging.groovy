library (
	name: "kasa_logging",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common Logging and info gathering Methods",
	category: "utilities",
	documentationLink: ""
)

def listAttributes() {
	def attrData = device.getCurrentStates()
	Map attrs = [:]
	attrData.each {
		attrs << ["${it.name}": it.value]
	}
	return attrs
}

def setLogsOff() {
	def logData = [logEnable: logEnable]
	if (logEnable) {
		runIn(1800, debugLogOff)
		logData << [debugLogOff: "scheduled"]
	}
	return logData
}

def logTrace(msg){ log.trace "${device.displayName}: ${msg}" }

def logInfo(msg) { 
	if (infoLog) {
		log.info "${device.displayName}: ${msg}"
	}
}

def debugLogOff() {
	device.updateSetting("logEnable", [type:"bool", value: false])
	logInfo("debugLogOff")
}

def logDebug(msg) {
	if (logEnable) {
		log.debug "${device.displayName}: ${msg}"
	}
}

def logWarn(msg) { log.warn "${device.displayName}: ${msg}" }

def logError(msg) { log.error "${device.displayName}: ${msg}" }
