library (
	name: "kasaCommunications",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Kasa Communications Methods",
	category: "communications",
	documentationLink: ""
)

import groovy.json.JsonSlurper
import org.json.JSONObject

def getPort() {
	def port = 9999
	if (getDataValue("devicePort")) {
		port = getDataValue("devicePort")
	}
	return port
}

def sendCmd(command) {
	state.lastCommand = command
	def connection = device.currentValue("connection")
	if (connection == "LAN") {
		sendLanCmd(command)
	} else if (connection == "CLOUD") {
		sendKasaCmd(command)
	} else if (connection == "AltLAN") {
		sendTcpCmd(command)
	} else {
		logWarn("sendCmd: attribute connection is not set.")
	}
}

def sendLanCmd(command) {
	logDebug("sendLanCmd: [ip: ${getDataValue("deviceIP")}, cmd: ${command}]")
	def myHubAction = new hubitat.device.HubAction(
		outputXOR(command),
		hubitat.device.Protocol.LAN,
		[type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
		 destinationAddress: "${getDataValue("deviceIP")}:${getPort()}",
		 encoding: hubitat.device.HubAction.Encoding.HEX_STRING,
		 parseWarning: true,
		 timeout: 8,
		 ignoreResponse: false,
		 callback: "parseUdp"])
	try {
		sendHubCommand(myHubAction)
		if (state.errorCount > 0 && state.errorCount < 4) {
			runIn(9, handleCommsError, [overwrite: false])
		}
		state.errorCount += 1
	} catch (e) {
		logWarn("sendLanCmd: [ip: ${getDataValue("deviceIP")}, error: ${e}]")
		handleCommsError()
	}
}
def parseUdp(message) {
	def resp = parseLanMessage(message)
	if (resp.type == "LAN_TYPE_UDPCLIENT") {
		def clearResp = inputXOR(resp.payload)
		if (clearResp.length() > 1023) {
			if (clearResp.contains("preferred")) {
				clearResp = clearResp.substring(0,clearResp.indexOf("preferred")-2) + "}}}"
			} else if (clearResp.contains("child_num")) {
				clearResp = clearResp.substring(0,clearResp.indexOf("child_num") -2) + "}}}"
			} else {
				logWarn("parseUdp: [status: converting to altComms, error: udp msg can not be parsed]")
				logDebug("parseUdp: [messageData: ${clearResp}]")
				updateDataValue("altComms", "true")
				state.errorCount = 0
				sendTcpCmd(state.lastCommand)
				return
			}
		}
		def cmdResp = new JsonSlurper().parseText(clearResp)
		logDebug("parseUdp: ${cmdResp}")
		state.errorCount = 0
		distResp(cmdResp)
	} else {
		logWarn("parseUdp: [error: error, reason: not LAN_TYPE_UDPCLIENT, respType: ${resp.type}]")
		handleCommsError()
	}
}

def sendKasaCmd(command) {
	logDebug("sendKasaCmd: ${command}")
	def cmdResponse = ""
	def cmdBody = [
		method: "passthrough",
		params: [
			deviceId: getDataValue("deviceId"),
			requestData: "${command}"
		]
	]
	if (!parent.kasaCloudUrl || !parent.kasaToken) {
		logWarn("sendKasaCmd: Cloud interface not properly set up.")
		return
	}
	def sendCloudCmdParams = [
		uri: "${parent.kasaCloudUrl}/?token=${parent.kasaToken}",
		requestContentType: 'application/json',
		contentType: 'application/json',
		headers: ['Accept':'application/json; version=1, */*; q=0.01'],
		timeout: 10,
		body : new groovy.json.JsonBuilder(cmdBody).toString()
	]
	try {
		asynchttpPost("cloudParse", sendCloudCmdParams)
	} catch (e) {
		def msg = "sendKasaCmd: <b>Error in Cloud Communications.</b> The Kasa Cloud is unreachable."
		msg += "\nAdditional Data: Error = ${e}\n\n"
		logWarn(msg)
	}
}
def cloudParse(resp, data = null) {
	try {
		response = new JsonSlurper().parseText(resp.data)
	} catch (e) {
		response = [error_code: 9999, data: e]
	}
	if (resp.status == 200 && response.error_code == 0 && resp != []) {
		def cmdResp = new JsonSlurper().parseText(response.result.responseData)
		logDebug("cloudParse: ${cmdResp}")
		distResp(cmdResp)
	} else {
		def msg = "cloudParse:\n<b>Error from the Kasa Cloud.</b> Most common cause is "
		msg += "your Kasa Token has expired.  Run Kasa Login and Token update and try again."
		msg += "\nAdditional Data: Error = ${resp.data}\n\n"
		logDebug(msg)
	}
}

def sendTcpCmd(command) {
	logDebug("sendTcpCmd: ${command}")
	try {
		interfaces.rawSocket.connect("${getDataValue("deviceIP")}",
									 getPort().toInteger(), byteInterface: true)
	} catch (error) {
		logDebug("SendTcpCmd: [connectFailed: [ip: ${getDataValue("deviceIP")}, Error = ${error}]]")
	}
	state.response = ""
	interfaces.rawSocket.sendMessage(outputXorTcp(command))
}
def close() { interfaces.rawSocket.close() }
def socketStatus(message) {
	if (message != "receive error: Stream closed.") {
		logDebug("socketStatus: Socket Established")
	} else {
		logWarn("socketStatus = ${message}")
	}
}
def parse(message) {
	if (message != null || message != "") {
		def response = state.response.concat(message)
		state.response = response
		extractTcpResp(response)
	}
}
def extractTcpResp(response) {
	def cmdResp
	def clearResp = inputXorTcp(response)
	if (clearResp.endsWith("}}}")) {
		interfaces.rawSocket.close()
		try {
			cmdResp = parseJson(clearResp)
			distResp(cmdResp)
		} catch (e) {
			logWarn("extractTcpResp: [length: ${clearResp.length()}, clearResp: ${clearResp}, comms error: ${e}]")
		}
	} else if (clearResp.length() > 2000) {
		interfaces.rawSocket.close()
	}
}

def handleCommsError() {
	Map logData = [method: "handleCommsError"]
	if (state.errorCount > 0 && state.lastCommand != "") {
		unschedule("poll")
		runIn(60, setPollInterval)
		logData << [count: state.errorCount, command: state.lastCommand]
		switch (state.errorCount) {
			case 1:
			case 2:
			case 3:
				if (getDataValue("altComms") == "true") {
					sendTcpCmd(state.lastCommand)
				} else {
					sendCmd(state.lastCommand)
				}
				logDebug(logData)
				break
			case 4:
				updateAttr("commsError", "true")
				logData << [setCommsError: true, status: "retriesDisabled"]
				logData << [TRY: "<b>do CONFIGURE</b>"]
				logData << [commonERROR: "IP Address not static in Router"]
				logWarn(logData)
				break
			default:
				logData << [TRY: "<b>do CONFIGURE</b>"]
				logData << [commonERROR: "IP Address not static in Router"]
				logWarn(logData)
				break
		}
	}
}

private outputXOR(command) {
	def str = ""
	def encrCmd = ""
 	def key = 0xAB
	for (int i = 0; i < command.length(); i++) {
		str = (command.charAt(i) as byte) ^ key
		key = str
		encrCmd += Integer.toHexString(str)
	}
   	return encrCmd
}

private inputXOR(encrResponse) {
	String[] strBytes = encrResponse.split("(?<=\\G.{2})")
	def cmdResponse = ""
	def key = 0xAB
	def nextKey
	byte[] XORtemp
	for(int i = 0; i < strBytes.length; i++) {
		nextKey = (byte)Integer.parseInt(strBytes[i], 16)	// could be negative
		XORtemp = nextKey ^ key
		key = nextKey
		cmdResponse += new String(XORtemp)
	}
	return cmdResponse
}

private outputXorTcp(command) {
	def str = ""
	def encrCmd = "000000" + Integer.toHexString(command.length()) 
 	def key = 0xAB
	for (int i = 0; i < command.length(); i++) {
		str = (command.charAt(i) as byte) ^ key
		key = str
		encrCmd += Integer.toHexString(str)
	}
   	return encrCmd
}

private inputXorTcp(resp) {
	String[] strBytes = resp.substring(8).split("(?<=\\G.{2})")
	def cmdResponse = ""
	def key = 0xAB
	def nextKey
	byte[] XORtemp
	for(int i = 0; i < strBytes.length; i++) {
		nextKey = (byte)Integer.parseInt(strBytes[i], 16)	// could be negative
		XORtemp = nextKey ^ key
		key = nextKey
		cmdResponse += new String(XORtemp)
	}
	return cmdResponse
}
